package com.example.vaii;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaiiApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaiiApplication.class, args);
	}

}
