package com.example.vaii;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaiiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
